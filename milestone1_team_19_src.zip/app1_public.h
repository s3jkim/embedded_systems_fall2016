
int appSendTimerValToMsgQ(unsigned int millisecondsElapsed);
void flash_LEDS();